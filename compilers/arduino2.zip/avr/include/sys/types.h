#ifndef _SYS_TYPES_H_
#define _SYS_TYPES_H_ 1

typedef long off_t;

#endif
